create definer = bestuser@localhost trigger update_cities_in_countries_table_after_inserting_new_city
    after insert
    on cities
    for each row
BEGIN
    INSERT INTO cities_in_countries VALUES (NEW.country_id, NEW.id);
END;

